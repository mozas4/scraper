import XLSX from 'xlsx';
import XlsxPopulate from 'xlsx-populate';
import fs from 'fs';
import { ensureDir, slugify } from './config.js';
import { detectLifecycle, detectAnimalSize, detectAnimalType } from './classifiers.js';

// ── EAN Pool ──

export class EanPool {
  constructor(values = []) {
    this.values = values.filter(Boolean).map((v) => v.toString().trim());
    this.index = 0;
    this.used = [];
  }
  next() {
    if (this.index >= this.values.length) return null;
    const val = this.values[this.index++];
    this.used.push(val);
    return val;
  }
}

export const loadEans = (eanPath) => {
  if (!eanPath || !fs.existsSync(eanPath)) return new EanPool([]);
  const wb = XLSX.readFile(eanPath);
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  const vals = [];
  for (const row of rows) {
    for (const cell of row) {
      if (typeof cell === 'number' || (typeof cell === 'string' && /^\d{6,}$/.test(cell.trim()))) {
        vals.push(cell.toString().trim());
      }
    }
  }
  return new EanPool(vals);
};

// ── Template column loading (SheetJS — read-only) ──

export const loadColumns = (templatePath) => {
  const wb = XLSX.readFile(templatePath);
  const ws = wb.Sheets['Data'];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, range: 'A2:BA2' });
  return rows[0] || [];
};

// ── SKU generation ──

const buildSku = (productUrl, variantOptions, idx) => {
  const rawSlug = productUrl ? productUrl.split('/').pop() : '';
  const base = rawSlug ? decodeURIComponent(rawSlug).slice(0, 50) : `product-${idx}`;
  const variantCode =
    variantOptions.length > 0
      ? slugify(variantOptions.join('-')).slice(0, 20) || `opt${idx + 1}`
      : '';
  return variantCode ? `${base}-${variantCode}` : base;
};

// ── Row mapping ──

export const mapVariantToRow = (columns, product, variant, idx, eanPool) => {
  const price = variant.price || product.price || null;
  const variantTitle = variant.title || product.title;
  const optionValues = (variant.options || []).filter(
    (o) => o && o.toLowerCase() !== 'default title'
  );
  const offerSku =
    variant.sku || buildSku(product.url, optionValues, idx);
  const barcode = variant.barcode || eanPool.next();
  const summary = product.description ? product.description.slice(0, 240) : '';

  const lifecycle = detectLifecycle(product.title, product.description);
  const animalSize = detectAnimalSize(product.title, product.description);
  const animalType = detectAnimalType(product.title, product.description);

  const values = {
    category: product.category || '',
    shop_sku: offerSku,
    name: product.title,
    description: product.description || '',
    brand: product.brand || null,
    ean: barcode || null,
    summary,
    basePriceUnit: 'יחידות',
    basePrice: '',
    variantGroupCode: product.url ? decodeURIComponent(product.url.split('/').pop()) : offerSku,
    media: product.mainImage || null,
    prodCountry: '',
    htmlColorCode: '',
    productSizeTxt: optionValues[0] || '',
    variantImage: '',
    2025: lifecycle,
    2024: '',
    2023: animalSize,
    6114: '',
    5678: '',
    5584: '',
    6039: '',
    9907: animalType,
    5855: 'false',
    sku: offerSku,
    'product-id': offerSku,
    'product-id-type': 'SKU',
    'offer-description': variantTitle,
    'internal-description': product.url,
    price,
    'price-additional-info': '',
    quantity: '',
    'min-quantity-alert': '',
    state: 'חדש',
    'available-start-date': '',
    'available-end-date': '',
    'logistic-class': 'פריטים רגילים - רמת מחיר 1',
    'favorite-rank': '',
    'discount-price': '',
    'discount-start-date': '',
    'discount-end-date': '',
    'leadtime-to-ship': '',
    'max-order-quantity': '',
    'update-delete': 'UPDATE',
    'warranty-by': '',
    'import-type': 'none',
  };

  return columns.map((key) =>
    Object.prototype.hasOwnProperty.call(values, key) ? values[key] : ''
  );
};

// ── Excel writing (xlsx-populate — preserves formatting) ──

export const writeRows = async (rows, templatePath, outputPath) => {
  const wb = await XlsxPopulate.fromFileAsync(templatePath);
  const ws = wb.sheet('Data');
  rows.forEach((row, ri) => {
    row.forEach((val, ci) => {
      if (val !== undefined && val !== null && val !== '') {
        ws.cell(ri + 3, ci + 1).value(val);
      }
    });
  });
  ensureDir(outputPath);
  await wb.toFileAsync(outputPath);
};
