import XLSX from 'xlsx';
import XlsxPopulate from 'xlsx-populate';
import fs from 'fs';
import { ensureDir, slugify } from './config.js';
import { detectLifecycle, detectAnimalSize, detectAnimalType } from './classifiers.js';

// ── Size/measure extraction ──

const normalizeUnit = (rawUnit) => {
  const u = (rawUnit || '').toLowerCase();
  if (/קילו|ק"?ג|kg/.test(u)) return 'ק"ג';
  if (/גרם|ג'|g\b/.test(u)) return 'גרם';
  if (/מ"?ל|מל|ml/.test(u)) return 'מ"ל';
  if (/ליטר|liter|ltr|\bl\b/.test(u)) return 'ליטר';
  if (/ס"?מ|סמ|cm/.test(u)) return 'ס"מ';
  if (/מטר|meter|\bm\b/.test(u)) return 'מטר';
  if (/יחיד|יחידה|יחידות|pcs?|pack/.test(u)) return 'יחידה';
  return rawUnit?.trim() || '';
};

const toNumber = (value) => {
  if (value === undefined || value === null) return null;
  const n = Number(value.toString().replace(',', '.'));
  return Number.isFinite(n) ? n : null;
};

const parseSizeFromText = (text) => {
  if (!text) return null;
  const cleaned = text.replace(/\u00a0/g, ' ');

  // Dimension pattern like "170X50X50 ס"מ"
  const dimRe = /(\d+(?:[.,]\d+)?(?:\s*[xX×]\s*\d+(?:[.,]\d+)?)+)\s*(ס"?מ|סמ|cm|מ"?מ|mm)/i;
  const packRe = /(\d+(?:[.,]\d+)?)\s*[xX×*]\s*(\d+(?:[.,]\d+)?)\s*(קילו|ק"?ג|קג|kg|גרם|ג'?ר?ם?|g\b|ליטר|ltr?|liter|\bl\b|מ"?ל|מל|ml)/i;
  const singleRe = /(\d+(?:[.,]\d+)?)\s*(קילו|ק"?ג|קג|kg|גרם|ג'?ר?ם?|g\b|מ"?ל|מל|ml|ליטר|ltr?|liter|\bl\b|ס"?מ|סמ|cm)/i;
  const countRe = /(\d+(?:[.,]\d+)?)\s*(יחידות|יחידה|יח'|pcs?|pack)/i;

  // Try dimensions first (e.g. "170X50X50 ס"מ")
  let m = cleaned.match(dimRe);
  if (m) {
    const dims = m[1].trim();
    const unit = normalizeUnit(m[2]);
    return {
      measureText: `${dims} ${unit}`.trim(),
      unitType: `1 ${unit}`.trim(),
      unitsCount: 1,
    };
  }

  m = cleaned.match(packRe);
  if (m) {
    const packCount = toNumber(m[1]);
    const unitAmount = toNumber(m[2]);
    const unit = normalizeUnit(m[3]);
    if (packCount && unitAmount) {
      return {
        measureText: `${packCount} x ${unitAmount} ${unit}`.trim(),
        unitType: `${unitAmount} ${unit}`.trim(),
        unitsCount: packCount,
      };
    }
  }

  m = cleaned.match(singleRe);
  if (m) {
    const amount = toNumber(m[1]);
    const unit = normalizeUnit(m[2]);
    if (amount) {
      return {
        measureText: `${amount} ${unit}`.trim(),
        unitType: `1 ${unit}`.trim(),
        unitsCount: amount,
      };
    }
  }

  m = cleaned.match(countRe);
  if (m) {
    const units = toNumber(m[1]);
    if (units) {
      return {
        measureText: `${units} יחידות`,
        unitType: '1 יחידה',
        unitsCount: units,
      };
    }
  }

  return null;
};

const detectSizeFields = (product, variant) => {
  const sources = [variant?.title, (variant?.options || []).join(' '), product?.title, product?.description];
  for (const src of sources) {
    const info = parseSizeFromText(src);
    if (info) return info;
  }
  return { measureText: '', unitType: '', unitsCount: '' };
};

// ── EAN Pool ──

export class EanPool {
  constructor(values = []) {
    this.values = values.filter(Boolean).map((v) => v.toString().trim());
    this.index = 0;
    this.used = [];
  }
  next() {
    if (this.index >= this.values.length) return null;
    const val = this.values[this.index++];
    this.used.push(val);
    return val;
  }
}

export const loadEans = (eanPath) => {
  if (!eanPath || !fs.existsSync(eanPath)) return new EanPool([]);
  const wb = XLSX.readFile(eanPath);
  const ws = wb.Sheets[wb.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });
  const vals = [];
  for (const row of rows) {
    for (const cell of row) {
      if (typeof cell === 'number' || (typeof cell === 'string' && /^\d{6,}$/.test(cell.trim()))) {
        vals.push(cell.toString().trim());
      }
    }
  }
  return new EanPool(vals);
};

// ── Template column loading (SheetJS — read-only) ──

export const loadColumns = (templatePath) => {
  const wb = XLSX.readFile(templatePath);
  const ws = wb.Sheets['Data'];
  const rows = XLSX.utils.sheet_to_json(ws, { header: 1, range: 'A2:BA2' });
  return rows[0] || [];
};

// ── SKU generation ──

const buildSku = (productUrl, variantOptions, idx) => {
  const rawSlug = productUrl ? productUrl.split('/').pop() : '';
  const base = rawSlug ? decodeURIComponent(rawSlug).slice(0, 50) : `product-${idx}`;
  const variantCode =
    variantOptions.length > 0
      ? slugify(variantOptions.join('-')).slice(0, 20) || `opt${idx + 1}`
      : '';
  return variantCode ? `${base}-${variantCode}` : base;
};

// ── Row mapping ──

export const mapVariantToRow = (columns, product, variant, idx, eanPool) => {
  const price = variant.price || product.price || null;
  const variantTitle = variant.title || product.title;
  const optionValues = (variant.options || []).filter(
    (o) => o && o.toLowerCase() !== 'default title'
  );
  const offerSku =
    variant.sku || buildSku(product.url, optionValues, idx);

  // For branded products: use only the barcode from the page (don't assign pool EAN).
  // For unbranded/generic products: fall back to the EAN pool.
  const scrapedBarcode = variant.barcode || product.barcode || null;
  const barcode = scrapedBarcode || (product.brand ? '' : eanPool.next());
  const sizeFields = detectSizeFields(product, variant);

  const lifecycle = detectLifecycle(product.title, product.description);
  const animalSize = detectAnimalSize(product.title, product.description);
  const animalType = detectAnimalType(product.title, product.description);

  const values = {
    category: product.category || '',
    shop_sku: offerSku,
    name: product.title,
    description: product.description || '',
    brand: product.brand || '',
    ean: barcode || '',
    summary: sizeFields.measureText,
    basePriceUnit: sizeFields.unitType,
    basePrice: sizeFields.unitsCount,
    variantGroupCode: product.url ? decodeURIComponent(product.url.split('/').pop()) : offerSku,
    media: product.mainImage || '',
    prodCountry: '',
    htmlColorCode: variant.color || '',
    productSizeTxt: variant.sizeOption || sizeFields.measureText || '',
    variantImage: '',
    2025: lifecycle,
    2024: '',
    2023: animalSize,
    6114: '',
    5678: '',
    5584: '',
    6039: '',
    9907: animalType,
    5855: 'false',
    sku: offerSku,
    'product-id': offerSku,
    'product-id-type': 'SKU',
    'offer-description': variantTitle,
    'internal-description': product.url,
    price,
    'price-additional-info': '',
    quantity: '',
    'min-quantity-alert': '',
    state: 'חדש',
    'available-start-date': '',
    'available-end-date': '',
    'logistic-class': 'פריטים רגילים - רמת מחיר 1',
    'favorite-rank': '',
    'discount-price': '',
    'discount-start-date': '',
    'discount-end-date': '',
    'leadtime-to-ship': '',
    'max-order-quantity': '',
    'update-delete': 'UPDATE',
    'warranty-by': '',
    'import-type': 'none',
  };

  return columns.map((key) =>
    Object.prototype.hasOwnProperty.call(values, key) ? values[key] : ''
  );
};

// ── Excel writing (xlsx-populate — preserves formatting) ──

export const writeRows = async (rows, templatePath, outputPath) => {
  const wb = await XlsxPopulate.fromFileAsync(templatePath);
  const ws = wb.sheet('Data');
  const colCount = rows.length > 0 ? rows[0].length : 0;
  rows.forEach((row, ri) => {
    row.forEach((val, ci) => {
      // Always write the cell — use empty string to clear stale data
      ws.cell(ri + 3, ci + 1).value(val ?? '');
    });
  });
  ensureDir(outputPath);
  await wb.toFileAsync(outputPath);
};
