import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';

dotenv.config();

// ── Environment-driven configuration ──
export const BASE_URL = process.env.BASE_URL || 'https://www.primopets.store';
// Default to project-local files if env vars are not provided
export const TEMPLATE_PATH = process.env.TEMPLATE_PATH || path.resolve('speadsheet.xlsx');
export const EAN_PATH = process.env.EAN_PATH || path.resolve('ean.xlsx');
export const OUTPUT_PATH = process.env.OUTPUT_PATH || TEMPLATE_PATH;
export const CONCURRENCY = Number(process.env.CONCURRENCY || 4);
export const MAX_RETRIES = Number(process.env.MAX_RETRIES || 1);
export const USER_AGENT = process.env.USER_AGENT || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36';
export const PAGE_TIMEOUT = Number(process.env.PAGE_TIMEOUT || 20000);
export const POST_NAV_WAIT_MS = Number(process.env.POST_NAV_WAIT_MS || 500);

// ── Utility functions ──

export const ensureDir = (targetPath) => {
  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
};

export const slugify = (value) =>
  (value || '')
    .toString()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .toLowerCase();

/** Cartesian product of multiple arrays. */
export const cartesian = (...arrays) =>
  arrays.reduce((acc, arr) => acc.flatMap((combo) => arr.map((val) => [...combo, val])), [[]]);

/** Convert hex color value to Hebrew color name using hue classification. */
export const hexToColorName = (hex) => {
  if (!hex || !hex.startsWith('#') || hex.length < 7) return hex;
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  const l = (max + min) / 510;
  if (l < 0.15) return 'שחור';
  if (l > 0.85 && max - min < 30) return 'לבן';
  if (max - min < 20) return 'אפור';
  const delta = max - min;
  let hue;
  if (max === r) hue = ((g - b) / delta) * 60;
  else if (max === g) hue = (2 + (b - r) / delta) * 60;
  else hue = (4 + (r - g) / delta) * 60;
  const h = (hue + 360) % 360;
  if (h < 15 || h >= 345) return 'אדום';
  if (h < 45) return 'כתום';
  if (h < 65) return 'צהוב';
  if (h < 165) return 'ירוק';
  if (h < 195) return 'טורקיז';
  if (h < 260) return 'כחול';
  if (h < 290) return 'סגול';
  return 'ורוד';
};
