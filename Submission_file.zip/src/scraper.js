import { BASE_URL, PAGE_TIMEOUT, POST_NAV_WAIT_MS, cartesian, hexToColorName } from './config.js';

// ── Sitemap parsing ──

const extractLocsFromXml = async (page) => {
  const text = await page.content();
  return [...text.matchAll(/<loc[^>]*>([^<]+)<\/loc>/gi)].map((m) => m[1].trim());
};

const getProductSitemaps = async (page) => {
  try {
    await page.goto(`${BASE_URL}/sitemap.xml`, { waitUntil: 'domcontentloaded', timeout: PAGE_TIMEOUT });
    const maps = await extractLocsFromXml(page);
    const productMaps = maps.filter((u) => u.includes('store-products-sitemap'));
    if (productMaps.length) return productMaps;
  } catch (err) {
    console.warn('sitemap.xml fetch failed, falling back:', err.message);
  }
  return [`${BASE_URL}/store-products-sitemap.xml`];
};

/** Collect all product URLs from Wix sitemap XML. */
export const getAllProductUrls = async (context) => {
  const page = await context.newPage();
  const maps = await getProductSitemaps(page);
  const urls = new Set();
  for (const mapUrl of maps) {
    console.log(`Reading sitemap: ${mapUrl}`);
    await page.goto(mapUrl, { waitUntil: 'domcontentloaded', timeout: PAGE_TIMEOUT });
    const locs = await extractLocsFromXml(page);
    locs
      .filter((u) => u.includes('/product-page/') || u.includes('/products/'))
      .forEach((u) => urls.add(u));
    console.log(`  found ${locs.length} urls (total: ${urls.size})`);
  }
  await page.close();
  return Array.from(urls);
};

// ── Variant extraction via Playwright interaction ──

/**
 * Extract variant option groups from Wix product page UI.
 * Handles two Wix patterns: custom dropdowns and color pickers.
 */
const extractOptionGroups = async (page) => {
  const groups = [];

  // Pattern 1: Custom dropdown (sizes, flavors, etc.)
  const dropdownContainers = await page.locator('[data-hook="options-dropdown-container"]').all();
  for (const container of dropdownContainers) {
    const label = await container
      .locator('[data-hook="dropdown-label"]')
      .textContent()
      .catch(() => 'option');
    const btn = container.locator('[data-hook="dropdown-base"]');
    if ((await btn.count()) === 0) continue;

    await btn.click();
    await page.waitForTimeout(500);

    const items = await page.evaluate(() =>
      [...document.querySelectorAll('[role="listbox"] [role="option"]')]
        .map((o) => o.textContent.trim())
        .filter(Boolean)
    );

    // Close the dropdown
    await page.locator('[data-hook="product-title"]').click().catch(() => {});
    await page.waitForTimeout(200);

    if (items.length > 1) {
      groups.push({ name: label.replace(/\*/g, '').trim(), values: items });
    }
  }

  // Pattern 2: Color picker (radio buttons with hex values)
  const colorContainers = await page.locator('[data-hook="product-options-color-container"]').all();
  for (const container of colorContainers) {
    const label = await container
      .locator('[data-hook="color-picker-fieldset-label"]')
      .textContent()
      .catch(() => 'צבע');

    const hexValues = await container
      .locator('[data-hook="color-picker-item"] input[type="radio"]')
      .evaluateAll((inputs) => inputs.map((i) => i.value));

    if (hexValues.length > 1) {
      const colorNames = hexValues.map((hex) => hex);
      groups.push({ name: label.replace(/\*/g, '').trim(), values: colorNames, isColor: true });
    }
  }

  return groups;
};

// ── Product extraction ──

/** Extract product data and variants from a Wix product page. */
export const extractProduct = async (page, url) => {
  await page.goto(url, { waitUntil: 'domcontentloaded', timeout: PAGE_TIMEOUT });
  await page.waitForTimeout(POST_NAV_WAIT_MS + 2000);

  // Step 1: Extract base product data from JSON-LD and DOM
  const product = await page.evaluate(() => {
    const pickText = (sel) => document.querySelector(sel)?.textContent?.trim() || null;
    const pickMeta = (name, attr = 'name') =>
      document.querySelector(`meta[${attr}="${name}"]`)?.getAttribute('content') || null;

    const parseJsonLd = () => {
      for (const s of document.querySelectorAll('script[type="application/ld+json"]')) {
        try {
          const d = JSON.parse(s.textContent);
          const items = Array.isArray(d) ? d : [d];
          const p = items.find((i) => i['@type'] === 'Product');
          if (p) return p;
        } catch {
          continue;
        }
      }
      return null;
    };

    const ld = parseJsonLd();
    const brand = ld?.brand?.name || ld?.brand || pickMeta('product:brand', 'property') || null;
    const category = ld?.category || pickMeta('product:category', 'property') || null;
    const title =
      pickText('[data-hook="product-title"]') || pickText('h1') || ld?.name || document.title;

    const descEl = document.querySelector(
      '[data-hook="description"], [data-hook="info-section-description"]'
    );
    const descHtml = descEl?.innerHTML || ld?.description || pickMeta('description');
    const description = descHtml
      ? descHtml.replace(/<[^>]+>/g, ' ').replace(/&quot;/g, '"').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim()
      : null;

    let mainImage = null;
    if (ld?.image) {
      const imgs = Array.isArray(ld.image) ? ld.image : [ld.image];
      mainImage = typeof imgs[0] === 'string' ? imgs[0] : imgs[0]?.contentUrl || null;
    }
    if (!mainImage) mainImage = pickMeta('og:image', 'property');

    const sku = ld?.sku || null;
    const offer = ld?.Offers || ld?.offers;
    const offers = offer ? (Array.isArray(offer) ? offer : [offer]) : [];
    const ldPrice = offers[0]?.price ? Number(offers[0].price) : null;
    const metaPrice = pickMeta('product:price:amount', 'property');
    const price = ldPrice || (metaPrice ? Number(metaPrice) : null);
    // Try multiple sources for barcode/EAN
    let barcode = offers[0]?.gtin13 || offers[0]?.gtin || null;
    if (!barcode) {
      // Search for EAN/barcode pattern in all offers
      for (const o of offers) {
        const g = o?.gtin13 || o?.gtin || o?.gtin12 || o?.gtin8 || o?.isbn || null;
        if (g) { barcode = g; break; }
      }
    }
    if (!barcode) {
      // Look for barcode in page text (13-digit EAN pattern)
      const bodyText = document.body?.innerText || '';
      const eanMatch = bodyText.match(/\b(\d{13})\b/);
      if (eanMatch) barcode = eanMatch[1];
    }

    return { url: location.href, title, description, brand, category, mainImage, price, sku, barcode };
  });

  // Step 2: Extract variant options via Playwright UI interactions
  const optionGroups = await extractOptionGroups(page);

  // Step 3: Build variant list
  if (optionGroups.length > 0) {
    const combos = cartesian(...optionGroups.map((g) => g.values));
    product.variants = combos.map((combo) => {
      // Convert hex color values to readable names for display
      const displayCombo = combo.map((val, i) =>
        optionGroups[i]?.isColor ? hexToColorName(val) : val
      );

      // Capture color and first non-color option for downstream mapping
      let colorOption = null;
      let sizeOption = null;
      displayCombo.forEach((val, i) => {
        if (optionGroups[i]?.isColor && !colorOption) colorOption = val;
        if (!optionGroups[i]?.isColor && !sizeOption) sizeOption = val;
      });
      return {
        title: `${product.title} - ${displayCombo.join(' / ')}`,
        options: displayCombo,
        sku: null,
        color: colorOption,
        sizeOption,
        barcode: null,
        price: product.price,
      };
    });
  } else {
    product.variants = [
      {
        title: product.title,
        options: [],
        sku: product.sku,
        color: null,
        sizeOption: null,
        barcode: product.barcode,
        price: product.price,
      },
    ];
  }

  return product;
};
