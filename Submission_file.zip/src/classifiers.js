// Brand detection rules: maps keywords in product title/description to exact ReferenceData brand names.
// Order matters: longer/more-specific keywords must come first to avoid false positives.
export const BRAND_RULES = [
  { keywords: ['פרו פלאן', 'pro plan'], brand: 'פרו פלאן' },
  { keywords: ['רויאל קנין', 'royal canin'], brand: 'Royal Canin' },
  { keywords: ['הילס', 'hills', "hill's"], brand: 'הילס סיינס פלאן' },
  { keywords: ["מונג'", 'מונג ', 'monge'], brand: 'Monge' },
  { keywords: ['ווסט פאו', 'west paw'], brand: 'West Paw' },
  { keywords: ['קונג ', 'kong ', 'kong-'], brand: 'קונג' },
  { keywords: ['פרונטליין', 'frontline'], brand: 'FRONTLINE' },
  { keywords: ['סרסטו', 'seresto'], brand: 'סרסטו' },
  { keywords: ['פריסקיז', 'friskies'], brand: 'Friskies' },
  { keywords: ['אלפא', 'alpha'], brand: 'Alpha Spirit' },
  { keywords: ['דוגלי', 'dogly'], brand: 'דוגלי' },
  { keywords: ['אואסי', 'oasis'], brand: 'אואסי' },
  { keywords: ['דיקאן', 'decan'], brand: 'דיקאן' },
  { keywords: ['אמברוסיה', 'ambrosia'], brand: 'אמברוסיה' },
  { keywords: ['ברבקטו', 'bravecto'], brand: 'BRAVECTO' },
  { keywords: ['דלישס', 'delicious'], brand: 'דלישס' },
  { keywords: ['דיקסי', 'dixie'], brand: 'דיקסי' },
  { keywords: ['פלקסי', 'flexi'], brand: 'Flexi' },
  { keywords: ['באפלו', 'buffalo'], brand: 'Buffalo' },
];

/** Detect brand from product title + description using keyword rules. */
export const detectBrand = (title, description) => {
  const text = `${title || ''} ${description || ''}`.toLowerCase();
  for (const rule of BRAND_RULES) {
    if (rule.keywords.some((kw) => text.includes(kw.toLowerCase()))) return rule.brand;
  }
  return null;
};

/** Lifecycle: גור | בוגר | מבוגר */
export const detectLifecycle = (title, description) => {
  const text = `${title || ''} ${description || ''}`;
  if (/גור|puppy|kitten|junior/i.test(text)) return 'גור';
  if (/מבוגר|סניור|senior|סניוור|זקן|light/i.test(text)) return 'מבוגר';
  if (/בוגר|adult|בוגרים/i.test(text)) return 'בוגר';
  return '';
};

/** Animal size: קטן | בינוני | גדול | ענק */
export const detectAnimalSize = (title, description) => {
  const text = `${title || ''} ${description || ''}`;
  if (/ענק|giant/i.test(text)) return 'ענק';
  if (/גדול|large|גזע גדול/i.test(text)) return 'גדול';
  if (/בינוני|medium|מדיום/i.test(text)) return 'בינוני';
  if (/קטן|small|מיני|mini|גזע קטן/i.test(text)) return 'קטן';
  return '';
};

/** Animal type: כלב | חתול | כלב וחתול */
export const detectAnimalType = (title, description) => {
  const text = `${title || ''} ${description || ''}`;
  const hasDog = /כלב|לכלב|כלבים|לכלבים|גורים|dog|puppy/i.test(text);
  const hasCat = /חתול|לחתול|חתולים|לחתולים|kitten|cat/i.test(text);
  if (hasDog && !hasCat) return 'כלב';
  if (hasCat && !hasDog) return 'חתול';
  if (hasDog && hasCat) return 'כלב וחתול';
  return '';
};
