import { chromium } from 'playwright';
import pLimit from 'p-limit';
import path from 'path';
import fs from 'fs';

import {
  TEMPLATE_PATH, EAN_PATH, OUTPUT_PATH,
  CONCURRENCY, MAX_RETRIES, USER_AGENT, PAGE_TIMEOUT,
} from './config.js';
import { detectBrand } from './classifiers.js';
import { getAllProductUrls, extractProduct } from './scraper.js';
import { loadEans, loadColumns, mapVariantToRow, writeRows } from './excel.js';

const scrapeAll = async () => {
  const eanPool = loadEans(EAN_PATH);
  console.log(`Loaded ${eanPool.values.length} EANs`);

  const columns = loadColumns(TEMPLATE_PATH);
  console.log(`Loaded ${columns.length} columns from template`);

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({ userAgent: USER_AGENT });
  context.setDefaultTimeout(PAGE_TIMEOUT);

  const urls = await getAllProductUrls(context);
  console.log(`Found ${urls.length} product URLs`);

  const limit = pLimit(CONCURRENCY);
  const allRows = [];
  let processed = 0;
  let failed = 0;

  await Promise.all(
    urls.map((url) =>
      limit(async () => {
        let product = null;
        let lastErr = null;

        // Retry loop for transient failures (timeouts, network errors)
        for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
          const page = await context.newPage();
          try {
            product = await extractProduct(page, url);
            await page.close();
            break;
          } catch (err) {
            lastErr = err;
            await page.close();
            if (attempt < MAX_RETRIES) {
              console.warn(`Retry ${attempt + 1}/${MAX_RETRIES} for ${url}: ${err.message}`);
            }
          }
        }

        if (!product) {
          console.error(`Failed: ${url} — ${lastErr?.message}`);
          failed++;
          return;
        }

        // Enrich brand from title/description if not provided by the page
        if (!product.brand) {
          product.brand = detectBrand(product.title, product.description);
        }

        for (const [idx, variant] of product.variants.entries()) {
          allRows.push(mapVariantToRow(columns, product, variant, idx, eanPool));
        }

        processed++;
        const vInfo = product.variants.length > 1 ? ` (${product.variants.length} variants)` : '';
        console.log(`\u200EScraped ${processed}/${urls.length}: ${product.title}${vInfo}`);
      })
    )
  );

  await writeRows(allRows, TEMPLATE_PATH, OUTPUT_PATH);
  await browser.close();

  console.log(`\nDone: ${allRows.length} rows (${processed} products, ${failed} failed) → ${OUTPUT_PATH}`);

  if (eanPool.used.length) {
    fs.writeFileSync(
      path.join(path.dirname(OUTPUT_PATH), 'used-eans.json'),
      JSON.stringify(eanPool.used, null, 2)
    );
  }
};

scrapeAll().catch((err) => {
  console.error('Fatal', err);
  process.exit(1);
});
